var Window;

// Function that open the new Window
function def() { 
Window = window.open( "def.html");
 } 
 
 // Function that open the new Window
function Lemonde() { 
Window = window.open( "https://www.lemonde.fr/economie/article/2019/04/25/la-robotisation-devrait-engendrer-la-disparition-de-14-des-emplois-d-ici-20-ans-selon-l-ocde_5454666_3234.html");
 } 
 
 // Function that open the new Window
function Microsoft() { 
Window = window.open( "https://experiences.microsoft.fr/articles/intelligence-artificielle/comprendre-utiliser-intelligence-artificielle/")
}

 // Function that open the new Window
function Elon() { 
Window = window.open( "https://www.nytimes.com/2018/08/15/business/elon-musk-tesla-board.html")
}

// Function that open the new Window
function index() { 
Window = window.close( "def.html");
 } 
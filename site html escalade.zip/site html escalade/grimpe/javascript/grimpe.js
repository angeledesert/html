var Window;

// Function that open the new Window
function windowOpen() { 
Window = window.open( "https://blog.kazaden.com/les-differents-types-descalade/");
 } 
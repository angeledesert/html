var Window;

// Function that open the new Window
function windowOpen() { 
Window = window.open( "grimpe/grimpe.html");
 } 
 
 // Function that open the new Window
function windowOpen() { 
Window = window.open( "https://www.ffme.fr/");
 } 
 
 // Function that open the new Window
function windowOpen() { 
Window = window.open( "materiel/materiel.html")
}

 // Function that open the new Window
function windowOpen() { 
Window = window.open( "quizz/quizz.html")
}
var Window;

// Function that open the new Window
function windowOpen() { 
Window = window.open( "https://fr.wikipedia.org/wiki/Matériel_d%27escalade");
 } 
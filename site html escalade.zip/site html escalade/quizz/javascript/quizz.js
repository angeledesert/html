
 var Window;  
 
 
  // function that Closes the open Window
  function windowClose() { 
			Window.close(); 
			alert("Le JavaScript fonctionne !")
  }  
 
  function valider1() {
	  if (document.getElementById('serie1b').checked) {
	 alert('Bravo !!!')  
	 }     
	else {    
	alert('Votre réponse est incorrecte...')    
	}   
} 
 
  function valider2() { 
		if (document.getElementById('serie2a').checked) {
		alert('Bravo !!!')    } 
		else {    
		alert('Votre réponse est incorrecte...')    
		}  
} 
 
 